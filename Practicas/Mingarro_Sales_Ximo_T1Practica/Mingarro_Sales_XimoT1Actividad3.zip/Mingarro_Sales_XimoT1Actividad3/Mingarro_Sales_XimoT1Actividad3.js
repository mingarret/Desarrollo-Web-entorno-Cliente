// 3. Tipo de dato de la variable string
alert(`El tipo de la variable texto es: ${typeof texto}`);

/*Actividad 3: Array de meses del año
b) Archivo JavaScript (actividad3.js):
Este archivo contiene un array con los meses del año y muestra alertas para los meses impares.*/

// Array de meses del año
const meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

// Mensajes de alerta para los meses impares
for (let i = 0; i < meses.length; i++) {
    if (i % 2 === 0) { // Meses impares (posición 0, 2, 4, etc.)
        alert(meses[i]);
    }
}
