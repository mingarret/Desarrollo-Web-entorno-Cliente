/*Práctica
Este ejercicio agrupa los siguientes ejercicios a realizar para la parte 
práctica y se debe enviar en el formato indicado 
(ver Anexo apartado “Uso de la instrucción Prompt” para la solicitud de 
datos por teclado). Cada funcionalidad indicada en cada uno de los ejercicios 
deberá codificarse en un fichero “js” distinto 
(se estructuran en un total de 6 apartados).*/

// 1. Suma de 5 números e identificar mayores de 100 (practica1.js):

let numeros = [];
let suma = 0;
let mayoresDe100 = 0;

for (let i = 0; i < 5; i++) {
    let num = parseInt(prompt(`Introduce el número ${i+1}:`, ""));
    numeros.push(num);
    suma += num;
    if (num > 100) {
        mayoresDe100++;
    }
}

alert(`La suma total es: ${suma}`);
alert(`Hay ${mayoresDe100} números mayores de 100`);




// 2. Sumar números mayores de 8 en un array (practica2.js):

const numerosArray = [6, 8, 3, 12, 18];
let sumaMayoresDe8 = 0;

for (let num of numerosArray) {
    if (num > 8) {
        sumaMayoresDe8 += num;
    }
}

alert(`La suma de los números mayores de 8 es: ${sumaMayoresDe8}`);




// 3. Identificar la estación del año según el mes (practica3.js):

let mes = prompt("Introduce un mes:", "").toLowerCase();

if (["diciembre", "enero", "febrero"].includes(mes)) {
    alert("Estamos en Invierno");
} else if (["marzo", "abril", "mayo"].includes(mes)) {
    alert("Estamos en Primavera");
} else if (["junio", "julio", "agosto"].includes(mes)) {
    alert("Estamos en Verano");
} else if (["septiembre", "octubre", "noviembre"].includes(mes)) {
    alert("Estamos en Otoño");
} else {
    alert("Mes no válido");
}
