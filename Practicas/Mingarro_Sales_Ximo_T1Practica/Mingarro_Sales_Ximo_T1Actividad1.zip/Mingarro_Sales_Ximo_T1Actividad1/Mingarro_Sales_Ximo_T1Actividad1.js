/*Actividad 1: Tipos de datos
Este archivo generará tres mensajes de alerta.*/

// Primer mensaje
alert("Hola mundo");

// Segundo mensaje con nombre completo
const nombreCompleto = "Juan Pérez González";
alert(nombreCompleto);

// Tercer mensaje sobre el uso de la función alert
alert("El comando alert es una función en JavaScript");
