/*Actividad 2: Operadores básicos
b) Archivo JavaScript (actividad2.js):
Este archivo contiene ejemplos de operadores básicos y muestra tres mensajes de alerta.*/

// 1. Suma de dos variables numéricas
let num1 = 15;
let num2 = 26;
alert(`La suma de ${num1} + ${num2} es: ${num1 + num2}`);

// 2. Suma de una variable string y una numérica
let texto = "15";
let numero = 26;
alert(`La suma de una cadena y un número es: ${texto} + ${numero} = ${texto + numero}`);
